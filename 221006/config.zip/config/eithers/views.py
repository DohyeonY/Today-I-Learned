from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_http_methods, require_POST, require_safe

from .models import Question
from .forms import QuestionForm, CommentForm
import random

# Create your views here.
@require_safe
def index(request):
    eithers = Question.objects.order_by('-pk')
    context = {
        'eithers': eithers,
    }
    return render(request, 'eithers/index.html', context)

@require_http_methods(['GET', 'POST'])
def create(request):
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            either = form.save()
            return redirect('eithers:detail', either.pk)
    else:
        form = QuestionForm()
    context = {
        'form': form,
    }
    return render(request, 'eithers/create.html', context)


@require_safe
def detail(request, pk):
    either = get_object_or_404(Question, pk=pk)
    comment_form = CommentForm()
    comments = either.comment_set.all()
    context = {
        'either': either,
        'comment_form': comment_form,
        'comments': comments,
    }
    return render(request, 'eithers/detail.html', context)


@require_POST
def delete(request, pk):
    either = get_object_or_404(Question, pk=pk)
    either.delete()
    return redirect('eithers:index')


@require_POST
def comments_create(request, pk):
    either = Question.objects.get(pk=pk)
    comment_form = CommentForm(request.POST)
    if comment_form.is_valid():
        comment = comment_form.save(commit=False)
        # comment.user = request.user
        comment.question_id = either
        comment.save()
    return redirect('eithers:detail', either.pk)

def random_page(request):
    entries = list(Question.objects.all())
    selected_page = random.choice(entries)
    return redirect('eithers:detail', selected_page.pk)